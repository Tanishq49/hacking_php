<!DOCTYPE HTML>
<HTML lang="en">
    <head>
        <title>Printing the variable values</title>
    </head>

<body>
  
    <?php

$name = "Trifalic Hacker";
echo "Hello {$name}";

$age = 14;
echo "<br>You are {$age} years old";

$users = 2;
echo "<br>There are {$users}users online";

$price = 100;
echo "<br>The price of this website is \${$price}";

$in_india = true;
echo "<br>Is the website in India? : The answer is {$in_india}";

echo "<br>We are printing the name of the user that is $name";

?>

</body>
</html>